package com.example.exam.repository;

import com.example.exam.model.entity.Word;
import com.example.exam.model.entity.enums.LanguageName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WordRepository extends JpaRepository<Word, String> {
    List<Word> findAllByLanguage_LanguageName(LanguageName languageName);

}
