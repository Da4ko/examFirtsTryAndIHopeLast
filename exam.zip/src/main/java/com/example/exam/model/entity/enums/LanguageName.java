package com.example.exam.model.entity.enums;

public enum LanguageName {
    GERMAN, SPANISH, FRENCH, ITALIAN
}
